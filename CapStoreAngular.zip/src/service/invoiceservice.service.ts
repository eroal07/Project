import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { InvoiceModel } from 'src/app/Model/invoice';

@Injectable({
  providedIn: 'root'
})
export class InvoiceserviceService {

  
  invoiceArr: InvoiceModel[];

  constructor(private router: Router) { 
    this.invoiceArr=[];
  }

  add(invoice: InvoiceModel) {
   // invoice.productId = Math.floor(Math.random() * 100);
    this.invoiceArr.push(invoice);
  }
}
