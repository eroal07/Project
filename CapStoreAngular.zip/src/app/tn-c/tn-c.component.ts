import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tn-c',
  templateUrl: './tn-c.component.html',
  styleUrls: ['./tn-c.component.css']
})
export class TnCComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
