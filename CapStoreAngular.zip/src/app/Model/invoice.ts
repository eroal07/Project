export class InvoiceModel{

    public productId:number;
    public productName:String;
    public productQuantity:number;
    public productPrice:number;
    public totalPrice:number;

}