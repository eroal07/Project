import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { InvoiceModel } from '../Model/invoice';
import { Router } from '@angular/router';
import * as jsPDF from 'jspdf';
import { InvoiceserviceService } from 'src/service/invoiceservice.service';


@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})

export class InvoiceComponent implements OnInit {

  ngxQrcode2 = 'https://material.angular.io/components/snack-bar/overview';

  invoiceArr: InvoiceModel[];




  constructor(private invoice: InvoiceModel, private router: Router,private invoiceService:InvoiceserviceService) {
    this.invoice.productId = 10;
    this.invoice.productName = "Samsung";
    this.invoice.productPrice = 10000;
    this.invoice.productQuantity = 2;
    this.invoice.totalPrice = this.invoice.productQuantity * this.invoice.productPrice;
    this.invoiceService.add(this.invoice);

  

    this.invoiceArr=this.invoiceService.invoiceArr;
  }

 

  /*@ViewChild('content') content: ElementRef;

  public downloadPDF() {


    let doc = new jsPDF();

    let specialElementHandlers = {
      '#editor': function (element :jsPDF, renderer:jsPDF) {
        return true;

      }

    };

    let content = this.content.nativeElement;

    doc.fromHTML(content.innerHTML, 15, 15, {
      'width': 190,
      'elementHandlers': specialElementHandlers
    });


    doc.save('invoice.pdf');
  }*/

  


  ngOnInit() {
  }
  navigateToTnc() {
    this.router.navigate(['tnc']);
  }

}
