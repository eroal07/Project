import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgxQRCodeModule } from 'ngx-qrcode2';

import { InvoiceComponent } from './invoice/invoice.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { InvoiceModel } from './Model/invoice';
import { TnCComponent } from './tn-c/tn-c.component';

@NgModule({
  declarations: [
    AppComponent,
    InvoiceComponent,
    TnCComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    NgxQRCodeModule
  ],
  providers: [InvoiceModel],
  bootstrap: [AppComponent]
})
export class AppModule { }
