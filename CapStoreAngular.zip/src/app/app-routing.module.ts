import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InvoiceComponent } from './invoice/invoice.component';
import { TnCComponent } from './tn-c/tn-c.component';

const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: 'invoice', component: InvoiceComponent, pathMatch: 'full' },
  { path: 'tnc', component: TnCComponent, pathMatch: 'full' },
  { path: '**', redirectTo: 'invoice', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
